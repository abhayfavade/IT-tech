import { Component } from '@angular/core';

@Component({
  selector: 'app-fresher-employment',
  templateUrl: './fresher-employment.component.html',
  styleUrl: './fresher-employment.component.css'
})
export class FresherEmploymentComponent {

}
