import { Component } from '@angular/core';

@Component({
  selector: 'app-our-clients',
  templateUrl: './our-clients.component.html',
  styleUrl: './our-clients.component.css'
})
export class OurClientsComponent {

}
