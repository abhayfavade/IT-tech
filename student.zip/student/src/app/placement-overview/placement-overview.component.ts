import { Component } from '@angular/core';

@Component({
  selector: 'app-placement-overview',
  templateUrl: './placement-overview.component.html',
  styleUrl: './placement-overview.component.css'
})
export class PlacementOverviewComponent {

}
