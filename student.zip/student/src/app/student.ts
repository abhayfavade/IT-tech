export class Student {
    id!: number;
    firstName!: string;
    lastName!: string;
    emailId!: string;
}
